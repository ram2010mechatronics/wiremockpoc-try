---
layout: splash
author_profile: true
title: About
---

# About WireMock

WireMock was originally created by [Tom Akehurst](http://tomakehurst.com) in 2011. Since then a whole host of people have been kind enough to contribute code, documentation and community support.

Many thanks to all of the following folks:

Adrian Ng<br>
[Akshay Deodhar](https://github.com/planetakshay)<br>
[Aman King](https://github.com/amanking)<br>
[Andrés Di Falco](https://github.com/adifalco)<br>
[Ashley Taylor](https://github.com/ashley-taylor)<br>
[Belema Gancarz](https://github.com/Belema)<br>
[Chris Batey](https://github.com/chbatey)<br>
[Christian Amann](https://github.com/camann9)<br>
[Christian Trimble](https://github.com/ctrimble)<br>
[Claudius Böttcher](https://github.com/clboettcher)<br>
[David Smith](https://github.com/shmish111)<br>
[Diego de Oliveira](https://github.com/diegooliveira)<br>
[Dipanjan Laha](https://github.com/dlaha21)<br>
[Dominic Tootell](https://github.com/tootedom)<br>
[Emma Burrows](https://github.com/emma-burrows)<br>
[Eric Driggs](https://github.com/edriggs)<br>
[Florian Lasinger](https://github.com/)<br>
[Gus Power](https://github.com/guspower)<br>
[James Ravn](https://github.com/jsravn)<br>
[Jamie Furnaghan](https://github.com/reines)<br>
[Jay Goldberg](https://github.com/carthoris)<br>
[Julian Vergel de Dios](https://github.com/jvergeldedios)<br>
[Kai Hofstetter](https://github.com/KaiHofstetter)<br>
[Kamil Szymański](https://github.com/kamilszymanski)<br>
[Kjetil Valstadsve](https://github.com/kjetilv)<br>
[Matt Nathan](https://github.com/mattnathan)<br>
[Mike Castleman](https://github.com/mlc)<br>
[Mike Rogers](https://github.com/mike-rogers)<br>
[Moritz Kammerer](https://github.com/)<br>
[Neil Green](https://github.com/neilg)<br>
[Nils Christian Haugen](https://github.com/nchaugen)<br>
[Oleg Kalnichevski](https://github.com/ok2c)<br>
[Oliver Schönherr](https://github.com/oschoen)<br>
[Paul Clarkin](https://github.com/paulclarkin)<br>
Paul Smith<br>
[Quenio dos Santos](https://github.com/quenio)<br>
R. Michael Rogers<br>
[Rainer Friesen](https://github.com/rainerfriesen)<br>
[Rob Elliot](https://github.com/Mahoney)<br>
[Rowan Hill](https://github.com/rowanhill)<br>
[Sam Edwards](https://github.com/handstandsam)<br>
[Sam Pengilly](https://github.com/sampengilly)<br>
[Sebastian Mancke](https://github.com/smancke)<br>
[Seth Bresnett](https://github.com/SethBresnettSoftwire)<br>
[Thomas LÉVEIL](https://github.com/thomasleveil)<br>
[Tim Perry](https://github.com/pimterry)<br>
[Todd Ricker](https://github.com/tricker)<br>
[Tomasz Wroniak](https://github.com/twroniak)<br>
[Zoran Regvart](https://github.com/zregvart)<br>
