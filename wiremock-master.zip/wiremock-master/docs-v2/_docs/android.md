---
layout: docs
title: 'Android'
toc_rank: 115
description: Running WireMock on the Android platform.
---

With some effort it is now possible to run WireMock on Android. Please see
[Sam Edwards' excellent blog post](http://handstandsam.com/2016/01/30/running-wiremock-on-android/) for instructions.
